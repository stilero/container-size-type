DROP TABLE IF EXISTS #__containercode_sizecode_firstchar;
DROP TABLE IF EXISTS #__containercode_sizecode_secondchar;
DROP TABLE IF EXISTS #__containercode_sizecode_type;
DROP TABLE IF EXISTS #__containercode_sizecode_typegroup;
